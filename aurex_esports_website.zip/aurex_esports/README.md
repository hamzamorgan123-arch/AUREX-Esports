# AUREX Esports Website

Responsive static esports organization website built with HTML, CSS and vanilla JavaScript.

## Run
1. Extract `aurex_esports_website.zip`.
2. Open the `aurex_esports` folder.
3. Double-click `index.html` to view it in your browser.
4. For editing, open the folder in Visual Studio Code.

## Customize
- `index.html`: organization content, divisions, roster, events, news, sponsors and contact labels.
- `styles.css`: theme and layout. Main theme variables are at the top (`--gold`, `--ice`, `--lime`).
- `script.js`: mobile navigation and contact form behavior. Replace `YOUR-EMAIL@example.com` with your public organization email to make the form open an email draft.

## Before publishing
Replace sample news, placeholder roster/match/sponsor details, and add your real social links and logo.
The contact form is front-end only and does not store submissions. For online applications, connect a form backend. The shop is a coming-soon visual, not a live checkout.
Google Fonts need internet access; fallback fonts are provided.
