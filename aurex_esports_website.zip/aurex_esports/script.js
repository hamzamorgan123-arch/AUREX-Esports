const menuButton=document.querySelector('.menu');
const nav=document.querySelector('.header nav');
menuButton.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuButton.setAttribute('aria-expanded',String(open));});
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuButton.setAttribute('aria-expanded','false');}));
document.getElementById('year').textContent=new Date().getFullYear();
document.getElementById('contactForm').addEventListener('submit',event=>{
  event.preventDefault();
  const data=new FormData(event.currentTarget);
  const note=document.getElementById('formNote');
  const recipient='YOUR-EMAIL@example.com'; // Replace with AUREX's public contact email.
  if(recipient==='YOUR-EMAIL@example.com'){
    note.textContent='Demo mode: replace YOUR-EMAIL@example.com in script.js with your organization email to enable email drafts.';
    note.style.color='#d9b56d'; return;
  }
  const subject=encodeURIComponent('AUREX Esports — '+data.get('topic'));
  const body=encodeURIComponent(`Name: ${data.get('name')}\nContact: ${data.get('reply')}\nTopic: ${data.get('topic')}\n\n${data.get('message')}`);
  window.location.href=`mailto:${recipient}?subject=${subject}&body=${body}`;
});
